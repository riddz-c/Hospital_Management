from django.contrib import admin
from .models import Doctor, Staff, HospitalLocation,ContactMessage,Appointment,Patient,Inquiry

admin.site.register(Doctor)
admin.site.register(Staff)
admin.site.register(HospitalLocation)
admin.site.register(ContactMessage)
admin.site.register(Appointment)
admin.site.register(Patient)
admin.site.register(Inquiry)
