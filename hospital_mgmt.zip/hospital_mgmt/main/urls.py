from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    path('about/', views.about),
    path('services/', views.services),
    path('departments/', views.departments),
    path('contact/', views.contact),
    path('appointment/', views.book_appointment),
    path('register/', views.patient_register),
    path('login/', views.patient_login),
    path('logout/', views.patient_logout),
    path('inquiry/', views.inquiry_view),
]
