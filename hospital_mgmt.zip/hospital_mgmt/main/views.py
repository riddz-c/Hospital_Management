from django.shortcuts import render

def home(request):
    return render(request, 'main/home.html')

def about(request):
    return render(request, 'main/about.html')

def services(request):
    return render(request, 'main/services.html')

def departments(request):
    return render(request, 'main/departments.html')

from .models import ContactMessage

def contact(request):
    success = False
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        ContactMessage.objects.create(name=name, email=email, message=message)
        success = True

    return render(request, 'main/contact.html', {'success': success})
from django.core.mail import send_mail
from django.conf import settings
from .models import Appointment, Patient, Doctor
import requests  # If you still have it from earlier (for SMS)

def book_appointment(request):
    patient_id = request.session.get('patient_id')
    if not patient_id:
        messages.error(request, "Please log in first.")
        return redirect('/login/')

    patient = Patient.objects.get(id=patient_id)
    doctors = Doctor.objects.all()
    success = False

    if request.method == 'POST':
        doctor_id = request.POST.get('doctor')
        date = request.POST.get('date')
        time = request.POST.get('time')
        reason = request.POST.get('reason')

        doctor = Doctor.objects.get(id=doctor_id)

        # Save the appointment
        appointment = Appointment.objects.create(
            patient=patient,
            doctor=doctor,
            name=patient.name,
            phone=patient.phone,
            email=patient.email,
            date=date,
            time=time,
            reason=reason
        )

        # ✅ Send email confirmation
        subject = "Appointment Confirmation"
        message = f"""Dear {patient.name},

Your appointment on {date} at {time} with {doctor.name} has been confirmed.

Thank you,
Hospital Management System
"""
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [patient.email],
            fail_silently=False,
        )

        success = True

    past_appointments = Appointment.objects.filter(patient=patient).order_by('-date')

    return render(request, 'main/appointment.html', {
        'doctors': doctors,
        'success': success,
        'patient': patient,
        'appointments': past_appointments
    })

from django.shortcuts import render, redirect
from .models import Patient
from django.contrib import messages
from .models import Inquiry

def patient_register(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Check if phone already registered
        if Patient.objects.filter(phone=phone).exists():
            messages.error(request, "Phone number already registered.")
            return redirect('/register/')
        else:
            Patient.objects.create(name=name, phone=phone, email=email, password=password)
            messages.success(request, "Registration successful. Please log in.")
            return redirect('/login/')

    return render(request, 'main/register.html')
def patient_login(request):
    if request.method == 'POST':
        phone = request.POST.get('phone')
        password = request.POST.get('password')

        try:
            patient = Patient.objects.get(phone=phone, password=password)
            request.session['patient_id'] = patient.id
            request.session['patient_name'] = patient.name
            messages.success(request, "Login successful!")
            return redirect('/appointment/')
        except Patient.DoesNotExist:
            messages.error(request, "Invalid phone or password.")
            return redirect('/login/')

    return render(request, 'main/login.html')
def patient_logout(request):
    request.session.flush()  # clears all session data
    messages.success(request, "You have been logged out.")
    return redirect('/login/')
def inquiry_view(request):
    if not request.session.get('patient_id'):
        messages.error(request, "Please log in first.")
        return redirect('/login/')

    patient = Patient.objects.get(id=request.session['patient_id'])
    success = False

    if request.method == "POST":
        msg = request.POST.get("message")
        Inquiry.objects.create(patient=patient, message=msg)
        success = True

    inquiries = Inquiry.objects.filter(patient=patient).order_by('-created_at')

    return render(request, 'main/inquiry.html', {
        'success': success,
        'inquiries': inquiries
    })

